import tkinter as tk
from tkinter import ttk
from System import *

class SideFrame(ttk.Frame):

    def __init__(self, master, **kw):
        super().__init__(master, **kw)


        #Key: menu in side bar
        #Value: page object
        self.pages = {}

        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        self.create_frame_treeview().grid(row=0, column=0, sticky='ens')

        self.create_frame_page().grid(row=0, column=1)





    def create_frame_page(self)->tk.Frame:
        '''
        Create the frame that will show current side page

        :return: ttk.Frame
        '''

        self.frame_page = tk.Frame(self)

        return self.frame_page

    def create_frame_treeview(self)->tk.Frame:
        '''
        Create the frame of side bar treeview widgets
        and instance the SideTreeview class

        :return: ttk.Frame
        '''

        self.frame_treeview = tk.Frame(self)
        self.treeview_sidebar = SideTreeview(self.frame_treeview)
        self.treeview_sidebar.bind('<<TreeviewSelect>>', self.on_treeview_select_changed)
        self.treeview_sidebar.pack(fill= tk.BOTH, expand=True)

        return self.frame_treeview
    
    def on_treeview_select_changed(self, event):
        '''
        Switch to the frame related to newly selected side bar

        '''

        selected_item = self.treeview_sidebar.focus()
        side_name = self.treeview_sidebar.item(selected_item).get('text')

        self.show_page(side_name)
        
    #Show a page
    def show_page(self, side_name: str):
        '''
        pack_forget() all pages
        and pack the given name
        '''

        for page_name in self.pages.keys():
            self.pages[page_name].pack_forget()

        self.pages[side_name].pack(fill=tk.BOTH, expand=True)

    def add_page(self, side_name:str, page):
        '''
        Instance a page frame and add to dictionary

        :parameter side_name: (str)
        :parameter page: a Page class
        :return: none
        '''


        #Add a page to dictionary so we can show it when needed
        self.pages[side_name] = page(self.frame_page)


        #Insert the sidebar name into the sidebar treeview
        self.treeview_sidebar.add_menu(section_text=side_name)
        
        


class SideTreeview(ttk.Treeview):

    def __init__(self, master, **kw):
        super().__init__(master, **kw)

        self.heading('#0', text='Navigation',)


    def add_menu(self, section_text: str):
        '''
        Insert a row
        
        :parameter section_text: str
        :return: none
        '''

        self.insert(parent='',
                    index=tk.END,
                    text=section_text)
 


class Page(tk.Frame):
    
    def __init__(self, master, **kw):
        super().__init__(master, **kw)


class LoginPage(Page):

    def __init__(self, master, **kw):
        super().__init__(master, **kw)
        
        self.create_frame_content().pack(fill=tk.BOTH, expand=True)


    def create_frame_content(self) -> tk.Frame:
        '''
        Create the widgets specific to Login Page

        :return: tk.Frame
        '''
        
        self.frame_content = tk.Frame(self)
        lbl_title = tk.Label(self.frame_content,
                              text='Login',
                              font=('Segoe UI',18, 'bold'),
                              foreground='crimson')
        lbl_title.pack(pady=12, anchor='n')
        frame1 = tk.Frame(self.frame_content, width=200)
        frame1.pack(padx=28, pady=(24,4), fill='both')

        labelusername = tk.Label(frame1,
                            text='Username',
                            font=('Segoe UI', 10, 'bold'),
                            foreground= 'grey15')
        labelusername.grid(row=0, column=0, padx=(12, 4), sticky='nsew')

        self.entryusername = tk.Entry(frame1,
                                font=('Segoe UI', 10),
                                width=32,
                                highlightcolor='crimson',
                                highlightthickness= 1)
        self.entryusername.grid(row=0, column=1, padx=(4,12), sticky='nsew')

        labelpassword = tk.Label(frame1,
                            text='Password',
                            font=('Segoe UI', 10, 'bold'),
                            foreground= 'grey15')
        labelpassword.grid(row=1, column=0, padx=(12, 4), sticky='nsew')

        self.entrypassword = tk.Entry(frame1,
                                font=('Segoe UI', 10, 'bold'),
                                width=32,
                                show="*",
                                highlightcolor='crimson',
                                highlightthickness= 1)
        self.entrypassword.grid(row=1, column=1, padx= (4,12), pady=(8,0), sticky='nsew')


        buttonlogin = tk.Button(self.frame_content,
                            text='Login',
                            font=('Segoe UI', 10, 'bold'),
                            bg='crimson',
                            fg='white',
                            borderwidth=0,
                            width=8,
                            command=self.login_user)
        buttonlogin.pack(padx=27, pady=(12,0), fill='x')
        return self.frame_content
    
    def username_check(self):
        
        cek=False
        ada = Hasher(self.entryusername.get(),self.entrypassword.get())

        conn = sqlite3.connect('DATABASE/user_data.db')
        c = conn.cursor()
        c.execute("SELECT * FROM user_data_table")

        items = c.fetchall()
        for item in items:
            if item[0]==ada.hash_username():
                cek=True
                break
            else:
                cek=cek
               

        if cek==True:
            self.password_check()
        else:
            WarningWindow('Username tidak ada')
    
    def password_check(self):

        cek=False
        ada = Hasher(self.entryusername.get(),self.entrypassword.get())

        conn = sqlite3.connect('DATABASE/user_data.db')
        c = conn.cursor()
        c.execute("SELECT * FROM user_data_table")

        items = c.fetchall()
        for item in items:
            if item[1]==ada.hash_userpw():
                cek=True
                break
            else:
                cek=cek
               

        if cek==True:
            show_data = CallData(ada.hash_password(), ada.hash_userpw())
            Dashboard(show_data.decrypt(item[2]), show_data.decrypt(item[3]), show_data.decrypt(item[4]), show_data.decrypt(item[5]))
              
        else:
            WarningWindow('Password salah!')

    def login_user(self):
        self.username_check()


class RegisterPage(Page):

    def __init__(self, master, **kw):
        super().__init__(master, **kw)

        self.create_frame_content().pack(fill=tk.BOTH, expand=True)

    def create_frame_content(self) -> tk.Frame:
        '''
        Create the widgets specific to Register Page

        :return: tk.Frame
        '''
        
        self.frame_content = tk.Frame(self)
        lbl_title = tk.Label(self.frame_content,
                              text='Register',
                              font=('Segoe UI',18, 'bold'),
                              foreground='crimson')
        lbl_title.pack(pady=12, anchor='n')
        frame1 = tk.Frame(self.frame_content, width=200)
        frame1.pack(padx=28, pady=(24,4), fill='both')

        labelusername = tk.Label(frame1,
                            text='Username',
                            font=('Segoe UI', 10, 'bold'),
                            foreground= 'grey15')
        labelusername.grid(row=0, column=0, padx=(12, 4), sticky='e')

        self.entryusername = tk.Entry(frame1,
                                font=('Segoe UI', 10),
                                width=33,
                                highlightcolor='crimson',
                                highlightthickness= 1)
        self.entryusername.grid(row=0, column=1, padx=(4,12), sticky='nsew')

        labelpassword = tk.Label(frame1,
                            text='Password',
                            font=('Segoe UI', 10, 'bold'),
                            foreground= 'grey15')
        labelpassword.grid(row=1, column=0, padx=(12, 4), sticky='e')

        self.entrypassword = tk.Entry(frame1,
                                font=('Segoe UI', 10, 'bold'),
                                width=33,
                                show="*",
                                highlightcolor='crimson',
                                highlightthickness= 1)
        self.entrypassword.grid(row=1, column=1, padx= (4,12), pady=(8,0), sticky='nsew')

        labelrepassword = tk.Label(frame1,
                            text='Confirm Password',
                            font=('Segoe UI', 10, 'bold'),
                            foreground= 'grey15')
        labelrepassword.grid(row=2, column=0, padx=(12, 4), sticky='e')

        self.entryrepassword = tk.Entry(frame1,
                                font=('Segoe UI', 10, 'bold'),
                                width=33,
                                show="*",
                                highlightcolor='crimson',
                                highlightthickness= 1)
        self.entryrepassword.grid(row=2, column=1, padx= (4,12), pady=(8,0), sticky='nsew')

        self.buttonregister = tk.Button(self.frame_content,
                            text='Register',
                            font=('Segoe UI', 10, 'bold'),
                            bg='crimson',
                            fg='white',
                            borderwidth=0,
                            width=8,
                            command=self.register_user)
        self.buttonregister.pack(padx=28, pady=(12,48), fill='x')
        return self.frame_content
    


    def username_check(self):
        try:
            if self.entryusername.get()=='':
                WarningWindow('Username tidak boleh kosong')
            else:
                cekspasi=False

                for i in range (len(self.entryusername.get())):
                    if self.entryusername.get()[i]==' ':
                        WarningWindow('Username tidak boleh memuat spasi')
                        cekspasi=True
                        break

                ada = Hasher(self.entryusername.get(),self.entrypassword.get())

                conn = sqlite3.connect('DATABASE/user_data.db')
                c = conn.cursor()
                c.execute("SELECT * FROM user_data_table")

                items = c.fetchall()
                for item in items:
                    if item[0]==ada.hash_username():
                        WarningWindow('Username sudah ada')
                        cekspasi=True
                        break
                    else:
                        cekspasi=cekspasi
                c.execute("SELECT *")       
                        
        except:      
            if cekspasi==False:
                self.password_check()
    
    def password_check(self):
        if self.entrypassword.get()=='':
            WarningWindow('Password tidak boleh kosong')
        else: 
            if self.entryrepassword.get()==self.entrypassword.get():
                filldata = FillData(self.entryusername.get(),self.entrypassword.get())
            else:
                WarningWindow('Konfirmasi ulang Password!')


    def register_user(self):
        self.username_check()


class AboutPage(Page):

    def __init__(self, master, **kw):
        super().__init__(master, **kw)

        self.create_frame_content().pack(fill=tk.BOTH, expand=True)

    def create_frame_content(self) -> tk.Frame:
        '''
        Create the widgets specific to Register Page

        :return: tk.Frame
        '''
        
        self.frame_content = tk.Frame(self)
        lbl_title = tk.Label(self.frame_content,
                              text='About Us',
                              font=('Segoe UI', 28, 'bold'),
                              foreground='crimson')
        lbl_title.pack(pady=12, anchor='n')
        frame1 = tk.Frame(self.frame_content, width=200)
        frame1.pack(padx=28, pady=(12,32), fill='both')
        fachri_lbl = tk.Label(frame1,
                            text='Fachri Hidayah Maliki Saddam',
                            font=('Segoe UI', 10, 'bold'),
                            foreground='grey15')
        fachri_lbl.grid(row=0, column=0, padx=(12,0), pady=4, sticky='w')
        NIMfachri_lbl = tk.Label(frame1,
                            text='2006263',
                            font=('Segoe UI', 10, 'bold'),
                            foreground='grey15')
        NIMfachri_lbl.grid(row=0, column=1, padx=20, pady=4, sticky='e')
        miftah_lbl = tk.Label(frame1,
                            text='Miftah Fadillah Sopian',
                            font=('Segoe UI', 10, 'bold'),
                            foreground='grey15')
        miftah_lbl.grid(row=1, column=0, padx=(12,0), pady=4, sticky='w')
        NIMmiftah_lbl = tk.Label(frame1,
                            text='2008079',
                            font=('Segoe UI', 10, 'bold'),
                            foreground='grey15')
        NIMmiftah_lbl.grid(row=1, column=1, padx=20, pady=4, sticky='e')
        aqil_lbl = tk.Label(frame1,
                            text='Muhammad Aqil Nizamuddin',
                            font=('Segoe UI', 10, 'bold'),
                            foreground='grey15')
        aqil_lbl.grid(row=2, column=0, padx=(12,0), pady=4, sticky='w')
        NIMaqil_lbl = tk.Label(frame1,
                            text='2003695',
                            font=('Segoe UI', 10, 'bold'),
                            foreground='grey15')
        NIMaqil_lbl.grid(row=2, column=1, padx=20, pady=4, sticky='e')
        reksa_lbl = tk.Label(frame1,
                            text='Reksa Alamsyah',
                            font=('Segoe UI', 10, 'bold'),
                            foreground='grey15')
        reksa_lbl.grid(row=3, column=0, padx=(12,0), pady=4, sticky='w')
        NIMreksa_lbl = tk.Label(frame1,
                            text='2008475',
                            font=('Segoe UI', 10, 'bold'),
                            foreground='grey15')
        NIMreksa_lbl.grid(row=3, column=1, padx=20, pady=4, sticky='e')
        return self.frame_content

class WarningWindow(tk.Toplevel):

    def __init__(self, warning):
        super().__init__()

        
        self.title('Notification')
        self.geometry('250x70')
        self.resizable(False, False)

        self.warning = warning
        
        self.frm = tk.Frame(self)
        self.frm.pack(padx=8, pady=8, fill=tk.BOTH)
        self.lbl = tk.Label(self.frm,
                            text= self.warning,
                            font=('Segoe UI', 10),
                            foreground='grey15')
        self.lbl.pack(fill=tk.BOTH, anchor=tk.CENTER)
        self.btn = tk.Button(self.frm,
                             text='OK',
                             font=('Segoe UI', 10),
                             background='crimson',
                             foreground='white',
                             highlightthickness=0,
                             relief='flat',
                             command=self.button_clicked)
        self.btn.pack(padx=20, fill=tk.BOTH)

        self.transient(self.master)
        self.grab_set()
        self.wait_window(self)

    def button_clicked(self):
        self.destroy()

class Dashboard(tk.Toplevel):

    def __init__(self, name, id, age, gender):
        super().__init__()

        self.title('Dashboard')
        self.geometry('400x250')
        self.resizable(False, False)

        self.name = name
        self.id = id
        self.age = age
        self.gender = gender

        self.main_frame = tk.Frame(self)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        self.main_lbl = tk.Label(self.main_frame,
                                 text=f'Welcome back!',
                                 foreground='grey15',
                                 font=('Segoe UI', 20, 'bold'),
                                 justify=tk.CENTER)
        self.main_lbl.pack(pady=(32,0), fill= tk.BOTH, anchor='center')
        self.name_lbl = tk.Label(self.main_frame,
                                 text=f'{self.name}',
                                 foreground='crimson',
                                 font=('Segoe UI', 14, 'bold'),
                                 justify=tk.CENTER)
        self.name_lbl.pack(padx=12, pady=(12,0), fill= tk.BOTH, anchor='center')
        self.id_lbl = tk.Label(self.main_frame,
                                 text=f'{self.id}',
                                 foreground='grey13',
                                 font=('Segoe UI', 12),
                                 justify=tk.CENTER)
        self.id_lbl.pack(padx=12, fill= tk.BOTH, anchor='center')
        self.age_lbl = tk.Label(self.main_frame,
                                 text=f'{self.age}',
                                 foreground='grey13',
                                 font=('Segoe UI', 12),
                                 justify=tk.CENTER)
        self.age_lbl.pack(padx=12, fill= tk.BOTH, anchor='center')
        self.gender_lbl = tk.Label(self.main_frame,
                                 text=f'{self.gender}',
                                 foreground='grey13',
                                 font=('Segoe UI', 12, 'bold'),
                                 justify=tk.CENTER)
        self.gender_lbl.pack(padx=12, fill= tk.BOTH, anchor='center')


        self.transient(self.master)
        self.grab_set()
        self.wait_window(self)




class FillData(tk.Toplevel):

    def __init__(self,username,password):
        self.username = username
        self.password = password
        super().__init__()

        self.title('Register Form')
        self.geometry('350x300')
        self.resizable(False, False)

        self.main_frame = tk.Frame(self)
        self.main_frame.pack(fill=tk.BOTH, expand=True)
        self.main_lbl = tk.Label(self.main_frame,
                                 text='Fill Account Data',
                                 foreground='crimson',
                                 font=('Segoe UI', 20, 'bold'),
                                 justify=tk.CENTER)
        self.main_lbl.pack(pady=(12,0), fill= tk.BOTH, anchor='center')
        
        self.entry_frame = tk.Frame(self.main_frame)
        self.entry_frame.pack(padx=30, pady=12,fill=tk.BOTH)
        self.name_lbl = tk.Label(self.entry_frame,
                                 text='Full Name',
                                 foreground='grey15',
                                 font=('Segoe UI', 8, 'bold'))
        self.name_lbl.grid(row=0, column=0, sticky='e')
        self.name_entry = tk.Entry(self.entry_frame,
                                font=('Segoe UI', 10),
                                width=28,
                                highlightcolor='crimson',
                                highlightthickness= 1)
        self.name_entry.grid(row=0, column=1, padx=(12,0), sticky='nsew')
        self.id_lbl = tk.Label(self.entry_frame,
                                 text='Student ID (NIM)',
                                 foreground='grey15',
                                 font=('Segoe UI', 8, 'bold'))
        self.id_lbl.grid(row=1, column=0, pady=(8,0), sticky='e')
        self.id_entry = tk.Entry(self.entry_frame,
                                font=('Segoe UI', 10),
                                width=28,
                                highlightcolor='crimson',
                                highlightthickness= 1)
        self.id_entry.grid(row=1, column=1, padx=(12,0), pady=(8,0), sticky='nsew')
        self.age_lbl = tk.Label(self.entry_frame,
                                 text='Age',
                                 foreground='grey15',
                                 font=('Segoe UI', 8, 'bold'))
        self.age_lbl.grid(row=2, column=0, pady=(8,0), sticky='e')
        self.age_entry = tk.Entry(self.entry_frame,
                                font=('Segoe UI', 10),
                                width=28,
                                highlightcolor='crimson',
                                highlightthickness= 1)
        self.age_entry.grid(row=2, column=1, padx=(12,0),pady=(8,0), sticky='nsew')
        self.gender_lbl = tk.Label(self.entry_frame,
                                 text='Gender',
                                 foreground='grey15',
                                 font=('Segoe UI', 8, 'bold'))
        self.gender_lbl.grid(row=3, column=0, pady=8, sticky='e')

        genderlist = ['Male', 'Female']
        self.gender = tk.StringVar()
        self.gender.set(genderlist[0])
        self.gender_menu = tk.OptionMenu(self.entry_frame,
                                         self.gender,
                                         *genderlist)
        self.gender_menu.config(background='white',
                                activebackground='crimson',
                                activeforeground='white',
                                relief='flat',
                                borderwidth=0)
        self.gender_menu.grid(row=3, column=1, padx=(12,0), sticky='w')
        self.attention = tk.Label(self.main_frame,
                                 text=f"Please mind, your data can't be changed later!",
                                 foreground='crimson',
                                 font=('Segoe UI', 8, 'bold'))
        self.attention.pack(pady=(8,0))


        self.buttonconfirm = tk.Button(self.main_frame,
                            text='Confirm',
                            font=('Segoe UI', 10, 'bold'),
                            bg='crimson',
                            fg='white',
                            borderwidth=0,
                            width=8,
                            command=self.input_register)
        self.buttonconfirm.pack(padx=28, pady=(0,12), fill='x')

        self.transient(self.master)
        self.grab_set()
        self.wait_window(self)

    def input_register(self):

        inp_reg = Hasher(self.username,self.password)

        ins_data = InsertData(inp_reg.hash_username(),inp_reg.hash_password(),inp_reg.hash_userpw(),self.name_entry.get(),self.id_entry.get(),self.age_entry.get(),self.gender.get())
        ins_data.insert_all()
        WarningWindow('Berhasil Register')


        self.destroy()
        

 





if __name__ == '__main__':
    root = tk.Tk()
    root.title('Himatika Recruitment')
    root.geometry('700x430')
    root.resizable(False, False)

    style = ttk.Style()

    style.configure('Treeview',
                    font = ('Segoe UI', 8, 'bold'),
                    rowheight=40)
    style.map('Treeview',
              foreground=[('selected', 'white')],
              background=[('selected', 'crimson')])
    style.configure('Treeview.Heading',
                font = ('Segoe UI', 12, 'bold'),
                foreground='crimson')

    

    sidebar = SideFrame(root)
    sidebar.add_page( side_name='    Login',
                     page=LoginPage)
    sidebar.add_page(side_name='    Register',
                     page=RegisterPage)
    sidebar.add_page(side_name='    About Us',
                     page=AboutPage)
    sidebar.pack(fill=tk.BOTH, expand=True)

    root.mainloop()