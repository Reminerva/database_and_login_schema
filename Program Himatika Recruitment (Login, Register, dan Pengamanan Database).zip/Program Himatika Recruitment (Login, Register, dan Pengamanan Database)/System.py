import hashlib
import sqlite3

conn = sqlite3.connect('DATABASE/user_data.db')
c = conn.cursor()

#c.execute("""CREATE TABLE user_data_table (
#    uhash text,
#    uphash text,
#    namac text,
#    nimc text,
#    umurc text,
#    genderc text
#)
#""")


class Hasher():

    def __init__(self, username:str, password:str):
        self.username = username
        self.password = password
    
    def hash_username(self)->str:
        salted_username = f'+%#^_^{self.username}^_^#%+'
        hashed = hashlib.sha256(salted_username.encode('utf-8')).hexdigest()
        return hashed
    
    def hash_password(self)->str:
        salted_password = f'>:($${self.password}$$):<'
        return hashlib.sha256(salted_password.encode('utf-8')).hexdigest()
    
    def hash_userpw(self)->str:
        salted_userpw = f'~0){self.username}V:V{self.password}(0~'
        hashed = hashlib.sha256(salted_userpw.encode('utf-8')).hexdigest()
        return hashed
    
class InsertData():

    def __init__(self, username, key, userpw, name, id, age, gender):
        self.username = username
        self.key = key
        self.userpw = userpw
        self.name = name
        self.id = id
        self.age = age
        self.gender = gender

    def encrypt(self, plainteks)->str:
        a=len(plainteks)
        b=len(self.key)
        if b<a:
            i=b
            while (i!=a):
                if(i%b==0):
                    j=0
                self.key=self.key+self.key[j]
                i=i+1
                j=j+1
        cipher=''
        for i in range(a):
            cipher=cipher+chr((ord(plainteks[i])+ord(self.key[i])-64)%95+32)
        return cipher
    
    def insert_all(self):
        conn = sqlite3.connect('DATABASE/user_data.db')
        c = conn.cursor()

        c.execute("INSERT INTO user_data_table VALUES (?,?,?,?,?,?)",(self.username,'','','','',''))
        c.execute("UPDATE user_data_table SET uphash=(?) WHERE uhash=(?)",(self.userpw, self.username))
        c.execute("UPDATE user_data_table SET namac=(?), nimc=(?), umurc=(?), genderc=(?) WHERE uhash=(?)", (self.encrypt(self.name), self.encrypt(self.id), self.encrypt(self.age), self.encrypt(self.gender), self.username))
        conn.commit()
        conn.close()

class CallData():

    def __init__(self, key, userpw ) :
        self.key = key
        self.userpw = userpw

    def decrypt(self, cipherteks ) -> str:
        a=len(cipherteks)
        b=len(self.key)
        if b<a:
            i=b
            while (i!=a):
                if(i%b==0):
                    j=0
                self.key=self.key+self.key[j]
                i=i+1
                j=j+1
        plain=''
        for i in range(a):
            plain=plain+chr((ord(cipherteks[i])-ord(self.key[i]))%95+32)
        return plain

#c.execute("DROP TABLE user_data_table")

conn.commit()
conn.close()